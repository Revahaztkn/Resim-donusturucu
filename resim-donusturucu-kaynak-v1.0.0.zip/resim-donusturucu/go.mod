module heicconverter

go 1.22.2
