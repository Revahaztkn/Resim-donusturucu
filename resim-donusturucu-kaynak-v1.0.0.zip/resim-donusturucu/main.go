package main

import (
	"embed"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"sync/atomic"
	"time"
)

//go:embed src/index.html src/heic-to.js
var files embed.FS

func main() {
	var last, byeAt atomic.Int64
	last.Store(time.Now().UnixMilli())
	var seen atomic.Bool
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		b, _ := files.ReadFile("src/index.html")
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(b)
	})
	mux.HandleFunc("/heic-to.js", func(w http.ResponseWriter, r *http.Request) {
		b, _ := files.ReadFile("src/heic-to.js")
		w.Header().Set("Content-Type", "application/javascript")
		w.Write(b)
	})
	mux.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		seen.Store(true)
		last.Store(time.Now().UnixMilli())
	})
	mux.HandleFunc("/bye", func(w http.ResponseWriter, r *http.Request) {
		byeAt.Store(time.Now().UnixMilli())
	})
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		fmt.Println("Cannot start:", err)
		os.Exit(1)
	}
	url := "http://" + ln.Addr().String() + "/"
	fmt.Println("HEIC to JPEG Converter running at", url)
	fmt.Println("Close the browser tab to exit.")
	go http.Serve(ln, mux)
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		exec.Command("open", url).Start()
	default:
		exec.Command("xdg-open", url).Start()
	}
	warned := false
	for {
		time.Sleep(time.Second)
		now := time.Now().UnixMilli()
		l, b := last.Load(), byeAt.Load()
		if seen.Load() && b > l && now-b > 3000 {
			return
		}
		if seen.Load() && now-l > 150000 {
			return
		}
		if !seen.Load() && !warned && now-l > 15000 {
			warned = true
			go showMessage("Image Converter", "The browser did not open automatically.\n\nOpen this address in your browser:\n"+url)
		}
		if !seen.Load() && now-l > 120000 {
			return
		}
	}
}
