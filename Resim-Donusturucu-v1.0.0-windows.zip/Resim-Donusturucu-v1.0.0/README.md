# Resim Dönüştürücü (Image Converter)

Simple, offline image converter for Windows. Double-click the `Resim Dönüştürücü.exe`, it opens in your browser and converts your images **locally on your computer**. Nothing is uploaded anywhere.

Basit ve çevrimdışı çalışan Windows resim dönüştürücü. `.exe` dosyasına çift tıkla, tarayıcında açılır ve resimlerini **tamamen bilgisayarında** dönüştürür. Hiçbir şey internete yüklenmez.

## Features / Özellikler

- HEIC/HEIF to JPEG, PNG, WebP, BMP (and JPEG/PNG/WebP/BMP to each other) / HEIC/HEIF'ten JPEG, PNG, WebP, BMP'ye ve bu formatların birbirine dönüşümü
- Choose source and target format; wrong files are rejected / Kaynak ve hedef format seçimi, yanlış formattaki dosyalar reddedilir
- Maximum quality, no quality slider / En yüksek kalite, kalite ayarı yok
- Any number of files, drag and drop (folders too) / Sınırsız dosya, sürükle-bırak (klasör dahil)
- Download each file or **Download All** (no ZIP) / Tek tek indir veya **Tümünü İndir** (ZIP yok)
- Turkish (default) and English, dark and light theme / Türkçe (varsayılan) ve İngilizce, karanlık ve aydınlık tema

## Usage / Kullanım

1. Download the zip from **Releases**, extract it. / **Releases** bölümünden zip'i indir, çıkar.
2. Run `Resim Dönüştürücü.exe`. Your browser opens. / `Resim Dönüştürücü.exe` dosyasını çalıştır, tarayıcın açılır.
3. Pick source and target format, drop your images. / Kaynak ve hedef formatı seç, resimleri bırak.
4. Close the browser tab to quit the app. / Uygulamadan çıkmak için tarayıcı sekmesini kapat.

> Windows SmartScreen or your antivirus may warn about an unsigned `.exe`. Click **More info > Run anyway**. You can verify the file with the SHA256 hash in the release notes, or build it yourself from source.
>
> İmzasız `.exe` için Windows SmartScreen veya antivirüs uyarı verebilir. **Ek bilgi > Yine de çalıştır** de. Release notlarındaki SHA256 ile doğrulayabilir ya da kaynaktan kendin derleyebilirsin.

## Notes / Notlar

- JPEG and WebP are lossy formats. Output uses the highest quality setting, but a tiny loss is inherent. PNG and BMP are lossless. / JPEG ve WebP kayıplı formatlardır, en yüksek kalite kullanılır ama çok küçük kayıp kaçınılmazdır. PNG ve BMP kayıpsızdır.
- EXIF metadata (date, location) is not preserved. / EXIF bilgileri (tarih, konum) korunmaz.
- Writing HEIC files is not supported. / HEIC çıktısı desteklenmiyor.

## Build from source / Kaynaktan derleme

Requires [Go](https://go.dev/) 1.22 or newer.

```
GOOS=windows GOARCH=amd64 go build -ldflags "-s -w -H windowsgui" -o "Resim Dönüştürücü.exe" .
```

The app icon and version info are embedded through `rsrc_windows_amd64.syso` (generated from `app.rc` and `icon.ico`, e.g. with `x86_64-w64-mingw32-windres`). Go picks it up automatically.

Works on Linux/macOS too without `GOOS` (a console build is easier for debugging: remove `-H windowsgui`).

## Credits / Teşekkürler

Decoding is done by [heic-to](https://github.com/hoppergee/heic-to) (LGPL-3.0), which is built on [libheif](https://github.com/strukturag/libheif). See `THIRD_PARTY_NOTICES.md`.

## License / Lisans

MIT, see `LICENSE`. Third-party components keep their own licenses.
